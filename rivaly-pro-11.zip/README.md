# Rivaly Pro

Bu sürüm Vercel/GitHub üzerinde direkt çalışır.

## Dosyalar
- index.html
- styles.css
- app.js

## Şu an çalışanlar
- Profesyonel responsive tasarım
- Valorant / eFootball filtreleri
- Oda oluşturma
- Katıl / Ayrıl
- 1/5 -> 5/5 canlı sayaç (tarayıcı içinde)
- AI-benzeri otomatik oyun tespiti
- Arama ve filtreleme
- Profil paneli
- localStorage ile cihazda kalıcı odalar

## Önemli
Bu sürüm statik frontend olduğu için odalar henüz farklı kullanıcılar arasında ortak değildir.
Bunu gerçek yapmak için sonraki adımda Supabase/Firebase gibi bir backend bağlanmalı.

VPN/proxy kontrolü de yalnızca backend tarafında güvenilir biçimde yapılabilir.
